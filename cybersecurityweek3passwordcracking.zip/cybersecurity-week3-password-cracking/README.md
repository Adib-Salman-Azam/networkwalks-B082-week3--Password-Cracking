# Week 3 Project – Password Cracking Lab

Two hands-on labs from Week 3 of a Cybersecurity & Ethical Hacking course (Networkwalks Academy), focused on recovering the password of a locked PDF file using two different approaches: an industry-standard offline tool (John the Ripper) and a browser-based dictionary attack tool (Networkwalks Hash Calculator / Password Cracker).

Both labs use the same underlying technique: extract a crackable hash from a password-protected file, then run that hash through a wordlist until a match is found. The goal is to understand password cracking from the attacker's perspective, in order to explain why weak passwords fail so quickly.

## ⚠️ Scope & ethics

All work here was done in an authorized training/lab environment, against a PDF file provided by the course specifically for this exercise. Password cracking should only ever be performed on systems and files you own or are explicitly authorized to test. This repo documents completed coursework, not a general-purpose cracking toolkit.

## Repository structure

```
cybersecurity-week3-password-cracking/
├── module-1-john-the-ripper/       # Password Cracking with John the Ripper (JTR) + Johnny GUI
│   ├── README.md
│   └── screenshots/
└── module-2-networkwalks-tools/    # Password Cracking with Networkwalks Hash Calculator & Password Cracker
    ├── README.md
    └── screenshots/
```

## Modules

| Module | Tool(s) | Attack type | Result |
|---|---|---|---|
| [1 – John the Ripper](./module-1-john-the-ripper) | John the Ripper (jumbo) + Johnny GUI | Dictionary attack via GUI | Password recovered, flag captured |
| [2 – Networkwalks Tools](./module-2-networkwalks-tools) | Networkwalks Hash Calculator + Password Cracker (browser-based) | Dictionary attack via web app | Password recovered, flag captured |

## Key concepts covered

- **Hashing vs. encryption** – encryption is reversible with the right key; hashing is a one-way function used to validate (not recover) data. A locked PDF stores a hash of its password, not the password itself.
- **Hash extraction** – tools like `pdf2john` / `pdf2hashcat` (and Networkwalks' browser-based Hash Calculator) convert a password-protected PDF into a crackable hash string (`$pdf$...`).
- **Dictionary attacks** – rather than brute-forcing every possible character combination, a wordlist of common/likely passwords is hashed and compared against the target hash until a match is found. This is exactly why weak or common passwords (e.g. dictionary words, "password123"-style patterns) are cracked in seconds to minutes.
- **GUI vs. browser-based tooling** – Johnny provides a point-and-click front end for John the Ripper on the desktop; the Networkwalks Password Cracker demonstrates the same concept fully client-side in a browser, with no installation required.

## Tools used

- [John the Ripper](https://www.openwall.com/john/) (jumbo build, Windows)
- [Johnny GUI](https://openwall.info/wiki/john/johnny)
- [Networkwalks Hash Calculator](https://networkwalks.com/hash-calculator/)
- [Networkwalks Password Cracker](https://networkwalks.com/password-cracker/)

## Takeaway

Both modules cracked their target PDF password in well under a minute against a small (~100-word) wordlist. That's the whole lesson in one sentence: a password that shows up in a common wordlist is not a password, it's a delay measured in seconds. Strong, unique, sufficiently long passwords (or a password manager) are what actually stand up to this class of attack.

---
*Course: Cybersecurity & Ethical Hacking — Networkwalks Academy, Week 3*

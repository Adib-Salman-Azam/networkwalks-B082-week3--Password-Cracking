# Module 1 — Password Cracking with John the Ripper (JTR)

**Task:** Crack the password of a protected PDF file using JTR John and JTR Johnny on Windows.

## Background

John the Ripper (JTR) is a widely used password cracking tool used by security professionals to test password strength. Originally built for Unix, it now runs on Windows, Linux, and macOS, and supports many hash types, including password-protected PDF, ZIP, and Office documents. Johnny is JTR's graphical front end — it wraps John's command-line engine in a point-and-click interface so an attack can be configured and run without typing commands directly.

## Steps performed

1. **Installed John the Ripper (jumbo build)** for Windows from the official [Openwall](https://www.openwall.com/john/) distribution. Jumbo John was used over core John because it supports more hash/attack types (including PDF hashes).
2. **Installed the Johnny GUI** from [openwall.info/wiki/john/johnny](https://openwall.info/wiki/john/johnny) and pointed it at the John the Ripper executable (`john.exe`) under *Settings*.
3. **Extracted the hash** from the locked PDF. The PDF's password is stored as a hash, not in plain text, so the hash first had to be pulled out of the file (via a `pdf2john`-style extractor) into a crackable `$pdf$...` format, then saved to a `.txt` file.
4. **Loaded the hash file into Johnny** via *Open password file*, then ran *Start new attack* to launch a dictionary attack against it.
5. **Password recovered.** Johnny reported `100% (1/1: 1 cracked, 0 left) [format=PDF]` — the attack matched the target hash to a real password.
6. **Verified the result** by opening the locked PDF and entering the cracked password, which unlocked the document and revealed a challenge flag confirming successful completion.

## Result

| Item | Value |
|---|---|
| Target file | Password-protected PDF (`format=PDF`) |
| Tool | John the Ripper 1.9.0-jumbo-1 (Cygwin 64-bit x86_64) via Johnny GUI |
| Attack type | Dictionary attack |
| Cracked password | `good-luck` |
| Flag captured | `nw{cybersecurity_flag_captured_2608}` |

## Screenshots

**1. Johnny configured with the John the Ripper executable, attack complete**
![Johnny settings – JTR configured, 100% cracked](./screenshots/01-johnny-jtr-configured.png)

**2. Cracked password shown in Johnny's Passwords view**
![Cracked password: good-luck](./screenshots/02-password-cracked.png)

**3. Flag captured after unlocking the PDF with the recovered password**
![Flag captured](./screenshots/03-flag-captured.png)

## Notes / lessons learned

- A locked PDF doesn't store the password itself — it stores a hash derived from it. Cracking means extracting that hash and testing candidate passwords against it offline, rather than repeatedly trying to "log in" to the file.
- Johnny is just a UI layer over John's engine; understanding the underlying `john` CLI workflow (hash extraction → wordlist attack → cracked output) is what actually matters, the GUI just removes the need to remember command syntax.
- On Kali Linux, JTR comes pre-installed, so this exercise can be repeated there without the install steps above.

# Module 2 — Password Cracking with Networkwalks Tools

**Task:** Crack the password of a protected PDF file using the Networkwalks Hash Calculator and Password Cracker (both browser-based, no install required).

## Background

Password cracking is the process of recovering a password from stored data or a protected file, used by security professionals to test how strong a password is. When a file is locked, its password is stored as a hash — a scrambled value representing the password. To recover the original password, the hash first has to be extracted from the file, then run through a cracking tool that hashes candidate words and checks for a match — the same idea behind John the Ripper, but reproduced here as a free, in-browser workflow.

## Steps performed

1. **Opened the Networkwalks Hash Calculator** ([networkwalks.com/hash-calculator](https://networkwalks.com/hash-calculator/)) and uploaded the locked PDF under the *PDF* tab.
2. **Extracted the hash.** The tool parsed the PDF entirely client-side (nothing is uploaded to a server) and returned a crackable hash in `pdf2john` / hashcat-compatible format, starting with `$pdf$...`, along with the PDF's revision, version, and key length.
3. **Copied the full hash value** and opened the **Networkwalks Password Cracker** ([networkwalks.com/password-cracker](https://networkwalks.com/password-cracker/)).
4. **Pasted the hash** into the Password Cracker and started the attack, which runs a dictionary attack in-browser — hashing every word in a wordlist and comparing it against the target hash, the same idea John the Ripper uses.
5. **Password recovered.** The tool worked through the built-in 100-word list and reported a match.
6. **Verified the result** by opening the locked PDF and entering the cracked password, which unlocked the document and revealed a challenge flag confirming successful completion.

## Result

| Item | Value |
|---|---|
| Target file | Password-protected PDF (`Revision: R4, Version: V4, Key length: 128 bit`) |
| Tools | Networkwalks Hash Calculator → Networkwalks Password Cracker |
| Attack type | Dictionary attack (built-in 100-word list) |
| Cracked password | `password1` |
| Flag captured | `nw{networkwalks_persistence_jtr_270521}` |

## Screenshots

**1. Hash Calculator extracting a crackable `$pdf$...` hash from the locked file**
![Hash Calculator output](./screenshots/01-hash-calculator.png)

**2. Password Cracker running the dictionary attack and reporting a match**
![Password Cracker – password cracked](./screenshots/02-password-cracker-result.png)

**3. Flag captured after unlocking the PDF with the recovered password**
![Flag captured](./screenshots/03-flag-captured.png)

## Notes / lessons learned

- Encryption and hashing are not the same thing: encryption is a two-way function (decrypt with the right key), while hashing is one-way (used to validate, not to reverse). A locked PDF's password is checked by hashing, which is exactly why it needs to be *cracked* rather than *decrypted*.
- The entire attack ran locally in the browser against a tiny, 100-word built-in list — no installation, no command line — and still cracked the password in well under a minute. That's the core lesson: a common or short password provides almost no real protection.
- This module reproduces the same underlying attack as Module 1 (dictionary attack against a `$pdf$` hash), just through a lightweight web tool instead of John the Ripper/Johnny — useful for understanding the concept without installing anything, though a real assessment would typically reach for John the Ripper or hashcat for speed and larger wordlists.
